<?php
echo "<p>Web desarrollada por blastoken<p>";
?>