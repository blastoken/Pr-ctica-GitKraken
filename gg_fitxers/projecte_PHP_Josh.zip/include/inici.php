<?php
echo"
<p>Los deportes electrónicos o eSports​ son competiciones de videojuegos que se han convertido en eventos de gran popularidad.</p>
<img src=\"img/esports.jpg\" width=\"100%\"  />
<p>Por lo general los deportes electrónicos son competiciones de videojuegos multijugador, los géneros más comunes en los videojuegos asociados a los esports son: estrategia en tiempo real, disparos en primera persona y MOBAs.</p>
";
 ?>
